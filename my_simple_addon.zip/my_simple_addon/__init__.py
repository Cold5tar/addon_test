bl_info = {
    "name": "My Simple Addon",
    "version": (1, 0, 0),
    "blender": (4, 20, 0),  # Specify the Blender version this addon is compatible with
    "category": "Object",
}

import bpy

# Define a simple operator that displays a message when executed
class OBJECT_OT_hello_world(bpy.types.Operator):
    bl_idname = "object.hello_world"
    bl_label = "Hello World Operator"
    bl_description = "A simple operator that says hello"

    def execute(self, context):
        self.report({'INFO'}, "Hello, World!")
        return {'FINISHED'}

# Function to add a new menu item in the "Object" menu
def menu_func(self, context):
    self.layout.operator(OBJECT_OT_hello_world.bl_idname)

# Register the addon and add the operator to the Object menu
def register():
    bpy.utils.register_class(OBJECT_OT_hello_world)
    bpy.types.VIEW3D_MT_object.append(menu_func)

# Unregister the addon and remove the operator from the Object menu
def unregister():
    bpy.utils.unregister_class(OBJECT_OT_hello_world)
    bpy.types.VIEW3D_MT_object.remove(menu_func)

if __name__ == "__main__":
    register()
